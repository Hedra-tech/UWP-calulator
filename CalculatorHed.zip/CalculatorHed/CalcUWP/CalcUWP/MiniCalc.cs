﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcUWP
{
    public class MiniCalc
    {
        public double Number1 { get; set; }
        public double Number2 { get; set; }

        public char Opertion { get; set; }
        public double Result { get; set; }
        public List<string> CalcHistory=new List<string>();

        public void equal()
        {
            try
            {
                switch (Opertion)
                {
                    case '+':
                        Result = Number1 + Number2;
                        CalcHistory.Add(string.Format("{0} + {1} = {2}",Number1,Number2,Result));
                        break;
                    case '-':
                        Result = Number1 - Number2;
                        CalcHistory.Add(string.Format("{0} - {1} = {2}", Number1, Number2, Result));
                        break;
                    case '*':
                        Result = Number1 * Number2;
                        CalcHistory.Add(string.Format("{0} × {1} = {2}", Number1, Number2, Result));
                        break;
                    case '/':
                        if (Number2 == 0)
                        {
                            throw new Exception("Obs!");
                        }
                        Result = Number1 / Number2;
                        CalcHistory.Add(string.Format("{0} ÷ {1} = {2}", Number1, Number2, Result));
                        break;
                }
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
    }
}
