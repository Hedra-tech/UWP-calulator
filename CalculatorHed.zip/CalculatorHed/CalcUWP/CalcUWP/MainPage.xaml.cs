﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.System;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace CalcUWP
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        MiniCalc MyCalculation = new MiniCalc();
        bool newCalculation=false;
        private void Numbers_Click(object sender, RoutedEventArgs e)
        {
            if(newCalculation==true)
            {
                CalcText.Text = "";
                newCalculation = false;
            }
            CalcText.Text += (sender as Button).Content;

        }

        private void Op_Click(object sender, RoutedEventArgs e)
        {
            newCalculation = false;
            MyCalculation.Number1 =double.Parse(CalcText.Text);
            CalcText.Text="";
            MyCalculation.Opertion=Convert.ToChar((sender as Button).Content);
        }

        private void comma(object sender, RoutedEventArgs e)
        {
            if (newCalculation == true)
            {
                CalcText.Text = "";
                newCalculation = false;
            }
            if (CalcText.Text.Contains('.') || CalcText.Text == "")
            {
                return;
            }
            else
            {
                CalcText.Text += ".";
            }


        }
        private async void sum(object sender, RoutedEventArgs e)
        {
            try
            {
                MyCalculation.Number2 = double.Parse(CalcText.Text);
                MyCalculation.equal();
                CalcText.Text = MyCalculation.Result.ToString();
                newCalculation = true;
                history.Items.Clear();
                foreach(var item in MyCalculation.CalcHistory)
                {
                    history.Items.Add(new TextBlock() { Text = item });
                }
            }
            catch (Exception)
            {
                MessageDialog message = new MessageDialog("Du måste ge nummer först!");
                await message.ShowAsync();
            }
        }

        private void Clear_All(object sender, RoutedEventArgs e)
        {
            MyCalculation = new MiniCalc();
            CalcText.Text = "";
            newCalculation = false;
        }

        private void CalcText_BeforeTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
        {
            //args.Cancel = args.NewText.Any(x => !char.IsNumber(x));
        }


    }
}
