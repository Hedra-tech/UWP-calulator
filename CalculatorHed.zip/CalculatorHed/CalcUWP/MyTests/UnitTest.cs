﻿using CalcUWP;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyTests
{
    [TestClass]
    public class UnitTest1
    {
        MiniCalc MyCalculation = new MiniCalc();

        [TestMethod]
        public void Plus()
        {
            MyCalculation.Number1 = 5;
            MyCalculation.Number2 = 6;
            MyCalculation.Opertion = '+';
            MyCalculation.equal();

            Assert.AreEqual(MyCalculation.Result, 11);

        }
    }
}
